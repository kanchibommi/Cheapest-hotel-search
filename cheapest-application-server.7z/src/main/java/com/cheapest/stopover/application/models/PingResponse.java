package com.cheapest.stopover.application.models;

public class PingResponse {

    private String message = "This is a ping response";

    public String getMessage() {
        return message;
    }

    public void setMessage(final String message) {
        this.message = message;
    }

}
